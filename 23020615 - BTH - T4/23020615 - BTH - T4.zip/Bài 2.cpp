#include <bits/stdc++.h>

using namespace std;

class SinglyLinkedListNode {
    public:
        int data;
        SinglyLinkedListNode *next;

        SinglyLinkedListNode(int node_data) {
            this->data = node_data;
            this->next = nullptr;
        }
};

class SinglyLinkedList {
    public:
        SinglyLinkedListNode *head;

        SinglyLinkedList() {
            this->head = nullptr;
        }

};

void print_singly_linked_list(SinglyLinkedListNode* node, string sep, ofstream& fout) {
    while (node) {
        fout << node->data;

        node = node->next;

        if (node) {
            fout << sep;
        }
    }
}

void free_singly_linked_list(SinglyLinkedListNode* node) {
    while (node) {
        SinglyLinkedListNode* temp = node;
        node = node->next;

        free(temp);
    }
}

// Lặp:
// SinglyLinkedListNode* insertNodeAtTail(SinglyLinkedListNode* head, int data) {
//     SinglyLinkedListNode* node = new SinglyLinkedListNode(data);
//     if (head == nullptr) return node;
//     SinglyLinkedListNode* current = head;
//     while(current->next != nullptr) {
//         current = current->next;
//     }
//     current->next = node;
//     return head;
// }
// ---

// Đệ quy
// SinglyLinkedListNode* insertNodeAtTail(SinglyLinkedListNode* head, int data) {
//     if (head == nullptr) {
//         return new SinglyLinkedListNode(data);
//     }
//     else {
//         head->next = insertNodeAtTail(head->next, data);
//     }
//     return head;
// }
//  ---

int main()
{
    ofstream fout(getenv("OUTPUT_PATH"));

    SinglyLinkedList* llist = new SinglyLinkedList();

    int llist_count;
    cin >> llist_count;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    for (int i = 0; i < llist_count; i++) {
        int llist_item;
        cin >> llist_item;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
      	SinglyLinkedListNode* llist_head = insertNodeAtTail(llist->head, llist_item);
        llist->head = llist_head;
    }

    print_singly_linked_list(llist->head, "\n", fout);
    fout << "\n";

    free_singly_linked_list(llist->head);

    fout.close();

    return 0;
}
